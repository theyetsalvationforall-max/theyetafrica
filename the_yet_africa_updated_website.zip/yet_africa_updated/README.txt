THE YET AFRICA WEBSITE UPDATE

This package updates the website to use the new blue, navy and gold ministry logo.

UPLOAD BOTH ITEMS TO YOUR EXISTING GITHUB REPOSITORY:
1. Replace the existing index.html in the repository root with this index.html.
2. Upload the assets folder and its yet-africa-logo.png file so the repository contains:
   assets/yet-africa-logo.png

Keep the assets folder name and file name exactly as shown. GitHub Pages will then load the logo from the relative path used by index.html.

Repository: https://github.com/theyetsalvationforall-max/theyetafrica
Website: https://theyetsalvationforall-max.github.io/theyetafrica/

If GitHub asks whether to replace index.html, choose to replace it and commit the changes.
